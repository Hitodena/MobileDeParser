class RequestException(Exception):
    pass


class OutOfProxiesException(Exception):
    pass
