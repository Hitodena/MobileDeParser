class HTMLParsingError(Exception):
    pass
