class ModelExclusionError(Exception):
    pass
